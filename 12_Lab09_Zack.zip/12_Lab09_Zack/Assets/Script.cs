﻿using System.Collections;
using System.Collections.Generic;
using System.Threading;
using UnityEngine;
using UnityEngine.UI;

public class Script : MonoBehaviour
{

    public float speed;
    float rotateSpeed = 30.0f;
    public GameObject lloydtext;
    Vector3 pos;
    
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKey(KeyCode.W))
            transform.position += transform.forward * speed * Time.deltaTime;
        else if (Input.GetKey(KeyCode.S))
            transform.position += new Vector3(0, 0, Time.deltaTime * -speed);
        else if (Input.GetKey(KeyCode.D))
            transform.Rotate(new Vector3(0, Time.deltaTime * rotateSpeed, 0));
        else if (Input.GetKey(KeyCode.A))
            transform.Rotate(new Vector3(0, Time.deltaTime * -rotateSpeed, 0));


        pos = transform.position;
        lloydtext.GetComponent<Text>().text = ("position:" +pos.x.ToString("F1")+","+pos.y.ToString("F1") + "," + pos.z.ToString("F1"));


    }
}
